import{B as e,G as t,H as n,I as r,K as i,P as a,Q as o,R as s,W as c,X as l,Z as u,at as d,et as f,it as p,n as m,ot as h,q as g,st as _,t as v,tt as y}from"./index-B-nfEHeW.js";var b=d({status:`uninitialized`}),x={state:b,subscribeKey(e,t){return p(b,e,t)},subscribe(e){return _(b,()=>e(b))},_getClient(){if(!b._client)throw Error(`SIWEController client not set`);return b._client},async getNonce(e){let t=await this._getClient().getNonce(e);return this.setNonce(t),t},async getSession(){try{let e=await this._getClient().getSession();return e&&(this.setSession(e),this.setStatus(`success`)),e}catch{return}},createMessage(e){let t=this._getClient().createMessage(e);return this.setMessage(t),t},async verifyMessage(e){return await this._getClient().verifyMessage(e)},async signIn(){return await this._getClient().signIn()},async signOut(){let e=this._getClient();await e.signOut(),this.setStatus(`ready`),this.setSession(void 0),e.onSignOut?.()},onSignIn(e){this._getClient().onSignIn?.(e)},onSignOut(){this._getClient().onSignOut?.()},setSIWEClient(e){b._client=h(e),b.status=`ready`,o.setIsSiweEnabled(e.options.enabled)},setNonce(e){b.nonce=e},setStatus(e){b.status=e},setMessage(e){b.message=e},setSession(e){b.session=e,b.status=e?`success`:`ready`}},S=n`
  :host {
    display: flex;
    justify-content: center;
    gap: var(--wui-spacing-2xl);
  }

  wui-visual-thumbnail:nth-child(1) {
    z-index: 1;
  }
`,C=function(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a},w=class extends s{constructor(){super(...arguments),this.dappImageUrl=o.state.metadata?.icons,this.walletImageUrl=t.state.connectedWalletInfo?.icon}firstUpdated(){let e=this.shadowRoot?.querySelectorAll(`wui-visual-thumbnail`);e?.[0]&&this.createAnimation(e[0],`translate(18px)`),e?.[1]&&this.createAnimation(e[1],`translate(-18px)`)}render(){return e`
      <wui-visual-thumbnail
        ?borderRadiusFull=${!0}
        .imageSrc=${this.dappImageUrl?.[0]}
      ></wui-visual-thumbnail>
      <wui-visual-thumbnail .imageSrc=${this.walletImageUrl}></wui-visual-thumbnail>
    `}createAnimation(e,t){e.animate([{transform:`translateX(0px)`},{transform:t}],{duration:1600,easing:`cubic-bezier(0.56, 0, 0.48, 1)`,direction:`alternate`,iterations:1/0})}};w.styles=S,w=C([r(`w3m-connecting-siwe`)],w);var T=function(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a},E=class extends s{constructor(){super(...arguments),this.dappName=o.state.metadata?.name,this.isSigning=!1,this.isCancelling=!1}render(){return this.onRender(),e`
      <wui-flex justifyContent="center" .padding=${[`2xl`,`0`,`xxl`,`0`]}>
        <w3m-connecting-siwe></w3m-connecting-siwe>
      </wui-flex>
      <wui-flex
        .padding=${[`0`,`4xl`,`l`,`4xl`]}
        gap="s"
        justifyContent="space-between"
      >
        <wui-text variant="paragraph-500" align="center" color="fg-100"
          >${this.dappName??`Dapp`} needs to connect to your wallet</wui-text
        >
      </wui-flex>
      <wui-flex
        .padding=${[`0`,`3xl`,`l`,`3xl`]}
        gap="s"
        justifyContent="space-between"
      >
        <wui-text variant="small-400" align="center" color="fg-200"
          >Sign this message to prove you own this wallet and proceed. Canceling will disconnect
          you.</wui-text
        >
      </wui-flex>
      <wui-flex .padding=${[`l`,`xl`,`xl`,`xl`]} gap="s" justifyContent="space-between">
        <wui-button
          size="lg"
          borderRadius="xs"
          fullWidth
          variant="neutral"
          ?loading=${this.isCancelling}
          @click=${this.onCancel.bind(this)}
          data-testid="w3m-connecting-siwe-cancel"
        >
          Cancel
        </wui-button>
        <wui-button
          size="lg"
          borderRadius="xs"
          fullWidth
          variant="main"
          @click=${this.onSign.bind(this)}
          ?loading=${this.isSigning}
          data-testid="w3m-connecting-siwe-sign"
        >
          ${this.isSigning?`Signing...`:`Sign`}
        </wui-button>
      </wui-flex>
    `}onRender(){x.state.session&&c.close()}async onSign(){this.isSigning=!0,y.sendEvent({event:`CLICK_SIGN_SIWE_MESSAGE`,type:`track`,properties:{network:f.state.caipNetwork?.id||``,isSmartAccount:t.state.preferredAccountType===l.ACCOUNT_TYPES.SMART_ACCOUNT}});try{x.setStatus(`loading`);let e=await x.signIn();return x.setStatus(`success`),y.sendEvent({event:`SIWE_AUTH_SUCCESS`,type:`track`,properties:{network:f.state.caipNetwork?.id||``,isSmartAccount:t.state.preferredAccountType===l.ACCOUNT_TYPES.SMART_ACCOUNT}}),e}catch{let e=t.state.preferredAccountType===l.ACCOUNT_TYPES.SMART_ACCOUNT;return e?u.showError(`This application might not support Smart Accounts`):u.showError(`Signature declined`),x.setStatus(`error`),y.sendEvent({event:`SIWE_AUTH_ERROR`,type:`track`,properties:{network:f.state.caipNetwork?.id||``,isSmartAccount:e}})}finally{this.isSigning=!1}}async onCancel(){this.isCancelling=!0,t.state.isConnected?(await g.disconnect(),c.close()):i.push(`Connect`),this.isCancelling=!1,y.sendEvent({event:`CLICK_CANCEL_SIWE`,type:`track`,properties:{network:f.state.caipNetwork?.id||``,isSmartAccount:t.state.preferredAccountType===l.ACCOUNT_TYPES.SMART_ACCOUNT}})}};T([a()],E.prototype,`isSigning`,void 0),T([a()],E.prototype,`isCancelling`,void 0),E=T([r(`w3m-connecting-siwe-view`)],E);export{x as SIWEController,m as getDidAddress,v as getDidChainId};